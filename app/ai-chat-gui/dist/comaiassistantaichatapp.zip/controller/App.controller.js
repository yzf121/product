sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("com.ai.assistant.aichatapp.controller.App",{onInit:function(){}})});
//# sourceMappingURL=App.controller.js.map